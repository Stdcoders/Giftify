import { useState, useEffect, useRef } from "react";
import { FaFilter } from "react-icons/fa";
import FilterSidebar from "../components/Products/FilterSidebar";
import SortOptions from "../components/Products/SortOptions";

const CollectionPage = () => {
  const [products, setProducts] = useState([]);
  const sidebarRef = useRef(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleClickOutside = (e) => {
    if (sidebarRef.current && !sidebarRef.current.contains(e.target)) {
      setIsSidebarOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    setTimeout(() => {
      const fetchedProducts = [
        {
          _id: "1",
          name: "Coffee Mug",
          price: 150,
          images: [
            {
              url: "https://cdn.pixabay.com/photo/2016/11/22/21/25/coffee-1850612_1280.jpg",
              altText: "Coffee Mug",
            },
          ],
        },
        {
          _id: "2",
          name: "Paint Set",
          price: 200,
          images: [
            {
              url: "https://cdn.pixabay.com/photo/2016/09/20/18/49/brushes-1683134_1280.jpg",
              altText: "Paint Set",
            },
          ],
        },
        {
          _id: "3",
          name: "Wall Hanging",
          price: 300,
          images: [
            {
              url: "https://cdn.pixabay.com/photo/2016/11/29/05/01/lights-1867437_1280.jpg",
              altText: "Wall Hanging",
            },
          ],
        },
        {
          _id: "4",
          name: "Makeup Kit",
          price: 500,
          images: [
            {
              url: "https://cdn.pixabay.com/photo/2016/10/22/20/55/makeup-brushes-1761648_1280.jpg",
              altText: "Makeup Kit",
            },
          ],
        },
      ];
      setProducts(fetchedProducts);
    }, 1000);
  }, []);

  return (
    <div className="flex flex-col lg:flex-row">
      {/* Mobile Filter button */}
      <button
        onClick={toggleSidebar}
        className="lg:hidden border p-2 flex justify-center items-center mb-4"
      >
        <FaFilter className="mr-2" /> Filters
      </button>

      {/* Filter sidebar */}
      <div
        ref={sidebarRef}
        className={`${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        } fixed inset-y-0 z-50 left-0 w-64 bg-white overflow-y-auto transition-transform duration-300 lg:static lg:translate-x-0`}
      >
        <FilterSidebar />
      </div>

      {/* Main content area */}
      <div className="flex-1 p-4">
        {/* Stacked header section */}
        <div className="mb-6">
          <h2 className="text-2xl uppercase mb-2">ALL COLLECTION</h2>
          <SortOptions />
        </div>

        {/* Product grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {products.map((product) => (
            <div key={product._id} className="border rounded overflow-hidden">
              <img
                src={product.images[0].url}
                alt={product.images[0].altText}
                className="w-full h-48 object-cover"
              />
              <div className="p-2">
                <h3 className="font-medium">{product.name}</h3>
                <p className="text-gray-600">${product.price}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CollectionPage;
