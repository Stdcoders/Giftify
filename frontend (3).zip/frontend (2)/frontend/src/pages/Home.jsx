/* eslint-disable no-unused-vars */
import React from 'react';
import Hero from '../components/layout/Hero';
import Collection1 from '../components/Products/Collection1';
import OurProducts from '../components/Products/OurProducts';
import BestSeller from '../components/Products/BestSeller'
import FeatureSection from '../components/Products/FeatureSection';
const Home = () => {
  return (
    <div>
      <Hero/>
      <Collection1/>
      <OurProducts/>

      {/*Bestseller Section*/}
      <h2 className='text-3xl text-center font-bold mb-4'>
        Best Seller
      </h2>
      <BestSeller />
      <FeatureSection/>
    </div>
  )
}

export default Home
