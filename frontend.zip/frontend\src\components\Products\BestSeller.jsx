/* eslint-disable no-unused-vars */
import {  useState } from "react";
import { toast } from "sonner";

const BestSeller = () => {
    const bestProduct = {
        name: 'Wall Hanging',
        price: 600,
        originalprice: 700,
        description: "Moons and Stars Wall Hanging",
        brand: 'Giftify',
        material: 'Art n Craft',
        colors: ['Black', 'Silver', 'Gold'],
        quantity:1,
        images: [
            {
                url: "https://i.pinimg.com/474x/1c/64/4d/1c644d945bd7f5b39729cd22fd7e9a66.jpg",
                altText: 'Wall Hanging 1',
            },
            {
                url: "https://i.pinimg.com/474x/1e/6b/75/1e6b755e4ae07613edda82a03d4265f0.jpg",
                altText: 'Wall Hanging 2',
            },
        ]
    };
    
    const [mainImage, setMainImage] = useState(bestProduct.images[0].url);
    const [selectedcolor, setselectedcolor] = useState("");
    const [quantity, setQuantity] = useState(1);
    const [isButtonDisabled, setisButtonDisabled] = useState(false);

    const handleQuantityChange = (action) => {
        if (action === "plus") setQuantity((prev) => prev + 1);
        if (action === "minus" && quantity > 1) setQuantity((prev) => prev - 1);
    }

    const handleAddToCart = () => {
        if (!selectedcolor) {
            toast.error("Please select color before adding to cart!", {
                duration: 1000,
            })
            return;
        }

        setisButtonDisabled(true);

        setTimeout(() => {
            toast.success("Product added to Cart!", {
                duration: 1000,
            })
            setisButtonDisabled(false);
        }, 500)
    }
    return (
        <div className='p-6'>
            <div className='max-w-6xl mx-auto bg-white p-8 rounded-lg'>
                <div className='flex flex-col md:flex-row'>
                    {/* Left Side - Images */}
                    <div className='md:w-1/2 flex flex-col items-center'>
                        <div className='mb-4 w-full'>
                            <img
                                src={mainImage}
                                alt="Main Product"
                                className='w-full h-auto object-cover rounded-lg'
                            />
                        </div>
                        <div className='flex space-x-4 overflow-x-auto'>
                            {bestProduct.images.map((image, index) => (
                                <img
                                    key={index}
                                    src={image.url}
                                    alt={image.altText || `Thumbnail ${index}`}
                                    onClick={() => setMainImage(image.url)}
                                    className={`w-20 h-20 object-cover rounded-lg cursor-pointer border ${mainImage === image.url ? 'border-black' : ''}`}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Right Side - Product Info */}
                    <div className='md:w-1/2 md:pl-10 flex flex-col justify-center'>
                        <h1 className='text-2xl md:text-3xl font-semibold mb-2'>
                            {bestProduct.name}
                        </h1>
                        <p className='text-lg text-gray-600 mb-1 line-through'>
                            {bestProduct.originalprice && `$${bestProduct.originalprice}`}
                        </p>
                        <p className='text-xl text-gray-500 mb-2'>
                            ${bestProduct.price}
                        </p>
                        <p className='text-gray-600 mb-4'>
                            {bestProduct.description}
                        </p>

                        <div className='mb-4'>
                            <p className='text-gray-700'>Color:</p>
                            <div className='flex gap-2 mt-2'>
                                {bestProduct.colors.map((color) => (
                                    <button
                                        key={color}
                                        className={`w-8 h-8 rounded-full border ${selectedcolor === color ? 
                                            "border-4 border-black" : "border-gray-300"
                                        }`}
                                        onClick={() => setselectedcolor(color)}
                                        style={{
                                            backgroundColor: color.toLowerCase(),
                                            filter: "brightness(0.5)",
                                        }}
                                    ></button>
                                ))}
                            </div>
                        </div>

                        <div className='mb-6'>
                            <p className='text-gray-700'>Quantity</p>
                            <div className='flex items-center space-x-4 mt-2'>
                                <button
                                onClick={() => handleQuantityChange("minus")}
                                className='px-2 py-1 bg-gray-200 rounded text-lg'>
                                    -
                                </button>
                                <span className='text-lg'>{quantity}</span>
                                <button
                                onClick={() => handleQuantityChange("plus")}
                                className='px-2 py-1 bg-gray-200 rounded text-lg'>
                                    +
                                </button>
                            </div>
                        </div>

                        <button
                            onClick={handleAddToCart}
                            disabled={isButtonDisabled}
                            className={`text-white py-2 px-6 
                                rounded w-full mb-4 bg-black
                                ${isButtonDisabled
                                ? "cursor-not-allowed"
                                : "hover:bg-gray-900"}`}>
                            {isButtonDisabled ? "Adding..." : "Add to Cart"}
                        </button>

                        <div className='mt-10 text-gray-700'>
                            <h3 className='text-xl font-bold mb-4'>
                                Characteristics:
                            </h3>
                            <table className='w-full text-left text-sm text-gray-600'>
                                <tbody>
                                    <tr>
                                        <td className='py-1'>Brand</td>
                                        <td className='py-1'>{bestProduct.brand}</td>
                                    </tr>
                                    <tr>
                                        <td className='py-1'>Material</td>
                                        <td className='py-1'>{bestProduct.material}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BestSeller;