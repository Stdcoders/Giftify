import React, { useEffect, useState } from 'react'

const MyOrders = () => {
    const [orders, setorders] = useState([]);

    useEffect(() => {
        setTimeout(() => {
            const mockOrders = [
                {
                    _id: 123,
                    createAt: new Date(),
                    shippingAddress: { city: 'Pune', country: 'India' },
                    orderItems: [
                        {
                            name: 'Product 1',
                            image: "https://cdn.pixabay.com/photo/2014/10/04/17/27/glass-473758_1280.jpg",
                        }
                    ],
                    totalprice: 200,
                    isPaid: true,
                }
            ]

            setorders(mockOrders);
        },1000)
    }, [])
  return (
    <div className='max-w-7xl mx-auto p-4 sm:p-6'>
          <h2 className='text-xl sm:text-2xl font-bold mb-6'>
              My Orders</h2>
          <div className='relative shadow-md sm:rounded-lg overflow-hidden'>
              <table className='min-w-full text-left text-gray-500'>
                  <thead className='bg-gray-100 text-xs uppercase text-gray-700'>
                      <tr>
                          <th className='py-2 px-4 sm:py-3'>Image</th>
                          <th className='py-2 px-4 sm:py-3'>Order ID</th>
                          <th className='py-2 px-4 sm:py-3'>Created</th>
                          <th className='py-2 px-4 sm:py-3'>Shipping Address</th>
                          <th className='py-2 px-4 sm:py-3'>Items</th>
                          <th className='py-2 px-4 sm:py-3'>Price</th>
                          <th className='py-2 px-4 sm:py-3'>Status</th>
                      </tr>
                  </thead>
                  <tbody>
                      
                  </tbody>
              </table>
          </div>
    </div>
  )
}

export default MyOrders
