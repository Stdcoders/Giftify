/* eslint-disable no-unused-vars */
import React, { useEffect, useRef, useState } from "react";
import { FiChevronLeft, FiChevronRight } from "react-icons/fi";
import { Link } from "react-router-dom";

const OurProducts = () => {
  const scrollRef = useRef(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const products = [
    { _id: "1", name: "Coffee Mug", price: 150, images: [{ url: "https://cdn.pixabay.com/photo/2016/11/22/21/25/coffee-1850612_1280.jpg", altText: "Coffee Mug" }] },
    { _id: "2", name: "Paint Set", price: 200, images: [{ url: "https://cdn.pixabay.com/photo/2016/09/20/18/49/brushes-1683134_1280.jpg", altText: "Paint Set" }] },
    { _id: "3", name: "Wall Hanging", price: 300, images: [{ url: "https://cdn.pixabay.com/photo/2016/11/29/05/01/lights-1867437_1280.jpg", altText: "Wall Hanging" }] },
    { _id: "4", name: "Makeup Kit", price: 500, images: [{ url: "https://cdn.pixabay.com/photo/2016/10/22/20/55/makeup-brushes-1761648_1280.jpg", altText: "Makeup Kit" }] },
  ];

  const scroll = (direction) => {
    if (!scrollRef.current) return;
    const scrollAmt = direction === "left" ? -300 : 300;
    scrollRef.current.scrollBy({ left: scrollAmt, behavior: "smooth" });
  };

  const updateScrollButtons = () => {
    const container = scrollRef.current;
    if (container) {
      setCanScrollLeft(container.scrollLeft > 0);
      setCanScrollRight(container.scrollWidth > container.scrollLeft + container.clientWidth);
    }
  };

  useEffect(() => {
    const container = scrollRef.current;
    if (container) {
      container.addEventListener("scroll", updateScrollButtons);
    }
    return () => {
      if (container) {
        container.removeEventListener("scroll", updateScrollButtons);
      }
    };
  }, []);

  return (
    <section className="relative py-16 px-4 lg:px-0">
      <div className="container mx-auto text-center mb-10">
        <h2 className="text-3xl font-bold mb-4">Explore our products!</h2>
        <p className="text-lg text-gray-600 mb-8">Discover unique gifts for your loved ones!</p>
      </div>

      {/* Scroll Buttons Positioned at the Top */}
      <div className="relative flex justify-between items-center mb-4 px-4">
        <button
          onClick={() => scroll("left")}
          disabled={!canScrollLeft}
          className={`p-2 rounded-full border shadow-md 
          ${canScrollLeft ? "bg-white text-black" : "bg-gray-200 text-gray-400 cursor-not-allowed"}`}
        >
          <FiChevronLeft className="text-2xl" />
        </button>
        <button
          onClick={() => scroll("right")}
          disabled={!canScrollRight}
          className={`p-2 rounded-full border shadow-md 
          ${canScrollRight ? "bg-white text-black" : "bg-gray-200 text-gray-400 cursor-not-allowed"}`}
        >
          <FiChevronRight className="text-2xl" />
        </button>
      </div>

      {/* Scrollable Product Container */}
      <div ref={scrollRef} className="container mx-auto overflow-x-auto flex space-x-6 relative scrollbar-hide">
        {products.map((product) => (
          <div key={product._id} className="min-w-[100%] sm:min-w-[50%] lg:min-w-[30%] relative">
            <img
              src={product.images[0]?.url}
              alt={product.images[0]?.altText || product.name}
              className="w-full h-[500px] object-cover rounded-lg"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-opacity-50 backdrop-blur-md text-white p-4 rounded-b-lg">
              <Link to={`/product/${product._id}`} className="block">
                <h4 className="font-medium">{product.name}</h4>
                <p className="mt-1">${product.price}</p>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default OurProducts;
