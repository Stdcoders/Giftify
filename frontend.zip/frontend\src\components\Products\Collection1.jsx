import React from 'react';
import { Link } from 'react-router-dom';

const Collection1 = () => {
    const decor = "https://cdn.pixabay.com/photo/2021/08/05/07/55/daffodils-6523446_1280.jpg";
    const fashion = "https://cdn.pixabay.com/photo/2015/10/08/20/44/gold-978372_1280.jpg";
    
    return (
        <section className='py-16 px-4 lg:px-4'>
            <div className='container mx-auto flex flex-col md:flex-row gap-8'>
                {/* Decor */}
                <div className='relative flex-1'>
                    <img 
                        src={decor} 
                        alt="Decor" 
                        className='w-full h-[500px] md:h-[600px] lg:h-[700px] object-cover rounded-lg'
                    />
                    <div className='absolute bottom-8 left-8 bg-white bg-opacity-90 p-4 rounded-md'>
                        <h2 className='text-2xl font-bold text-gray-900 mb-3'>Decor</h2>
                        <Link 
                            to='/collections/all?type=Decor' 
                            className='text-gray-900 underline'>
                            Shop Now!
                        </Link>
                    </div>
                </div>
                
                {/* Fashion & Accessories */}
                <div className='relative flex-1'>
                    <img 
                        src={fashion} 
                        alt="Fashion & Accessories" 
                        className='w-full h-[500px] md:h-[600px] lg:h-[700px] object-cover rounded-lg'
                    />
                    <div className='absolute bottom-8 left-8 bg-white bg-opacity-90 p-4 rounded-md'>
                        <h2 className='text-2xl font-bold text-gray-900 mb-3'>Fashion & Accessories</h2>
                        <Link 
                            to='/collections/all?type=Fashion' 
                            className='text-gray-900 underline'>
                            Shop Now!
                        </Link>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Collection1;
