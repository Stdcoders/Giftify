import React from 'react';
import Header from '../admin/cart/common/header';
import Footer from '../admin/cart/common/Footer';
import { Outlet } from 'react-router-dom';
const UserLayout = () => {
  return (
    <div>
      {/*Header*/}
      <Header/>
      {/*Main Content*/}
      <main>
        <Outlet/>
      </main>
      {/*Footer*/}
      <Footer/>
    </div>
  )
};

export default UserLayout;
